package com.example.farm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Random;

public class Gerador extends AppCompatActivity {
    EditText campodado;
    ImageView img;
    int number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gerador);
        getSupportActionBar().hide();
        campodado = findViewById(R.id.campo);
        img = findViewById(R.id.foto);

    }
    public void jogar (View a){
        try {
            number = Integer.parseInt(campodado.getText().toString());
        }
        catch (Exception e){
            number = 0;
            Toast.makeText(this,"falta dados",Toast.LENGTH_LONG).show();
        }
        Random randola = new Random();
        int gerado = randola.nextInt(number)+1;
        if (number == 33){
            if (gerado == 33){
                img.setImageResource(R.drawable.a33);
            }
        }
        if (number == 34){
            if (gerado == 33){
                img.setImageResource(R.drawable.a33);
            }
            else if (gerado == 34){
                img.setImageResource(R.drawable.a34);
            }
        }
        if (number == 35){
            if (gerado == 33){
                img.setImageResource(R.drawable.a33);
            }
            else if (gerado == 34){
                img.setImageResource(R.drawable.a34);
            }
           else if (gerado == 35){
                img.setImageResource(R.drawable.a35);
            }
        }
    }
}