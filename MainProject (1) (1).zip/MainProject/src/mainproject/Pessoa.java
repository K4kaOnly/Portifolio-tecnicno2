package mainproject;


public class Pessoa {
    private String nome;
    private String cpf;
    private String dataNasc;
    private String contato;
    private String genero;

    public Pessoa(String nome, String cpf, String dataNasc, String contato, String genero) {
        this.nome = nome;
        this.cpf = cpf;
        this.dataNasc = dataNasc;
        this.contato = contato;
        this.genero = genero;
    }
    
    public void registrar(String nome, String cpf, String dataNasc, String contato, String genero){
    
    
    }
    
    public boolean verificarPresenca(String nome, String cpf){
        return true;
    
    
    
    }
    
}
