package mainproject;

import java.util.ArrayList;

public class Presidio {
    ArrayList <Pessoa> formula;
    ArrayList <Pavilhao> pavilhao;
    ArrayList <String> transpote;
    String nome;
    String local;
    String contato;
    float despesa;
    float orcamento;
   private int lotacao;

    public Presidio(ArrayList<Pessoa> formula, ArrayList<Pavilhao> pavilhao, ArrayList<String> transpote, String nome, String local, String contato, float despesa, float orcamento, int lotacao) {
        this.formula = formula;
        this.pavilhao = pavilhao;
        this.transpote = transpote;
        this.nome = nome;
        this.local = local;
        this.contato = contato;
        this.despesa = despesa;
        this.orcamento = orcamento;
        this.lotacao = lotacao;
    }
   

   
    
}
