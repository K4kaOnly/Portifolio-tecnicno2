package mainproject;

import java.util.ArrayList;

public class Pavilhao extends Funcionario {
   private ArrayList<Presidiario> presidiario;
   private ArrayList <Funcionario> funcionario;
   private ArrayList <String> salaTecnico;
   private ArrayList <String> salaVisita;
   private int cela;
   private int refeitorio;
   private int banheiro;
   private int solitaria;
   private String id;
   private String tipo;
   private int Patio;
   private int biblioteca;
   private int lavanderia;
   private int salaDeAula;
   private int capela;
   private boolean lojaConveniencia;

    public Pavilhao(String cargo, int cargaHorario, boolean bateuPonto, String pis, float salario, float valeTransporte, float valeAlimentação, String nome, String cpf, String dataNasc, String contato, String genero) {
        super(cargo, cargaHorario, bateuPonto, pis, salario, valeTransporte, valeAlimentação, nome, cpf, dataNasc, contato, genero);
     this.presidiario = presidiario;
        this.funcionario = funcionario;
        this.salaTecnico = salaTecnico;
        this.salaVisita = salaVisita;
        this.cela = cela;
        this.refeitorio = refeitorio;
        this.banheiro = banheiro;
        this.solitaria = solitaria;
        this.id = id;
        this.tipo = tipo;
        this.Patio = Patio;
        this.biblioteca = biblioteca;
        this.lavanderia = lavanderia;
        this.salaDeAula = salaDeAula;
        this.capela = capela;
        this.lojaConveniencia = lojaConveniencia;
    }

    
       
    

  

    
    

   
}
