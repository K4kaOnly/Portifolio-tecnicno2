package mainproject;

import java.util.ArrayList;




public class Funcionario extends Pessoa{
    String cargo;
    int cargaHorario;
    boolean bateuPonto;
    String pis;
    float salario;
    float valeTransporte;
    float valeAlimentação;

  

    public Funcionario(String cargo, int cargaHorario, boolean bateuPonto, String pis, float salario, float valeTransporte, float valeAlimentação, String nome, String cpf, String dataNasc, String contato, String genero) {
        super(nome, cpf, dataNasc, contato, genero);
        this.cargo = cargo;
        this.cargaHorario = cargaHorario;
        this.bateuPonto = bateuPonto;
        this.pis = pis;
        this.salario = salario;
        this.valeTransporte = valeTransporte;
        this.valeAlimentação = valeAlimentação;
    }

    

  

  
    public boolean aumentarSalario (float valor, String nome){
        return true;
        
    
    }
    public boolean receberSalario(){
        return true;
    
    
    }
    public boolean receberVale(String Tipo){
        return true;
    
    
    }
    public boolean terFerias (String nomeFuncionario){
        return false;
    
    }
    public void trabalhar(){
    
    
    }
    public boolean fazerHoraExtra(){
        return false;
    
    }
    public boolean serTransferido(String Pavilhao){
        return true;
    
    }
    public void serDemitido(String nome, String motivo, String dia){
    
    
    
    }
    public void pedirDemissao(String nome, String motivo, String dia){
    
    
    
    }
    
    
}
