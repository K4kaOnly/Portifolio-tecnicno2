package mainproject;

public class Presidiario {
    private int codigo;
    private String crime;
    private int numCela;
    private String advogado;
    private int tempSentenca;
    private boolean julgamento;
    private boolean fianca;

    public Presidiario(int codigo, String crime, int numCela, String advogado, int tempSentenca, boolean julgamento, boolean fianca) {
        this.codigo = codigo;
        this.crime = crime;
        this.numCela = numCela;
        this.advogado = advogado;
        this.tempSentenca = tempSentenca;
        this.julgamento = julgamento;
        this.fianca = fianca;
    }
    
   public void tatuar(String tatoo){
   
   
   }
   public boolean receberVisita(String nome, String Data, String Hora){
       return false;
   
   }
   public boolean receberLigacao(String Nome, String Parentesco, String Tempo, String Data ){
       return true;
   
   }
   public boolean fazerLigacao(String nome, int numero, String Tempo, String Data){
       return false;
   
   
   } 
   public void serLiberado(String nome, String data){
       
   
   
   }
   
   public boolean serTransferido(int quantidade, Pavilhao pavilhao, String Data ){
       return false;
   
   
   }
   
   public void sair (String nome, String Data, String CPF){
   
   
   }
   
   public boolean comparecerAoJulgamento(String nome, String cpf, String sentenca, Funcionario funcionario){
       return true;
   
   }
   public boolean banhoDeSol(){
       return false;
   
   }
   public boolean recolher(int quantidade){
       return true;
   }
   public boolean irPraSolitaria(String nome, String CPF, int codigo){
       return false;
   
   }
       
       
       
    
}
