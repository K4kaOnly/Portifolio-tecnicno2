package mainproject;

import java.util.ArrayList;

public class Visitantes extends Pessoa {
   private String dataVisita;
   private int horaVisita;
   private int minVisita;
   private int horaSaida;
   private int minSaida;
   private ArrayList<String> Pertences;
   private String tipoVisita;
   private ArrayList<String> presente;
   private String relacao;

    public Visitantes(String nome, String cpf, String dataNasc, String contato, String genero) {
        super(nome, cpf, dataNasc, contato, genero);
    }

    public Visitantes(String dataVisita, int horaVisita, int minVisita, int horaSaida, int minSaida, ArrayList<String> Pertences, String tipoVisita, ArrayList<String> presente, String relacao, String nome, String cpf, String dataNasc, String contato, String genero) {
        super(nome, cpf, dataNasc, contato, genero);
        this.dataVisita = dataVisita;
        this.horaVisita = horaVisita;
        this.minVisita = minVisita;
        this.horaSaida = horaSaida;
        this.minSaida = minSaida;
        this.Pertences = Pertences;
        this.tipoVisita = tipoVisita;
        this.presente = presente;
        this.relacao = relacao;
    }
   public String revistar(String nome, String resultado){
       return null;
   
   
   }
 public boolean agendarVisita(String Nome, String cpf, int numero, int hora, String Data, String codigoPreso){
        return true;
   
   
   }
 public void presentear(String presente){
 
 
 }
 
}
