package mainproject;

public class AgentePenal extends Funcionario {
    
    public AgentePenal(String cargo, int cargaHorario, boolean bateuPonto, String pis, float salario, float valeTransporte, float valeAlimentação, String nome, String cpf, String dataNasc, String contato, String genero) {
        super(cargo, cargaHorario, bateuPonto, pis, salario, valeTransporte, valeAlimentação, nome, cpf, dataNasc, contato, genero);
        this.cargo = cargo;
        this.cargaHorario = cargaHorario;
        this.bateuPonto = bateuPonto;
        this.pis = pis;
        this.salario = salario;
        this.valeTransporte = valeTransporte;
        this.valeAlimentação = valeAlimentação;
    }
    public boolean vigiar(Pavilhao pavilhao){
        return true; 
    
    }
    public boolean acompanharPresidiario(Presidiario presidiario){
        return false;
    
    }
    public boolean transferenciaPresidiario(Presidiario presidiario){
        return true;
    
    }
    public void advertir(Presidiario presidiario, String motivo){
    
    
    }
    public void advertir(Visitantes visitante, String motivo){
    
    
    }
    public void advertir(Presidiario presidiario,Visitantes visitante, String motivo){
    
    
    }
    public boolean conferir (Presidiario presidiario){
        return false;
    
    
    }
    public boolean conferir(Pavilhao pavilhao){
        return true;
    
    
    }
    public boolean revistar(Presidiario presidiario){
        return false;
    
    
    }
    public boolean revistar(Pavilhao pavilhao){
        return true;
    
    
    }
    
    
    
     
    
}
