package com.example.calculadorahora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText HI,HF,MI,MF;
    TextView HT, MT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        HI = findViewById(R.id.edhora1);
        HF = findViewById(R.id.edhora2);
        MI = findViewById(R.id.edmin1);
        MF = findViewById(R.id.edmin2);
        HT = findViewById(R.id.viewHT);
        MT = findViewById(R.id.viewMT);
    }
    public void somaClick(View s){
        int valorTotalhoras;
        int valorTotalmin;

        int a = Integer.parseInt(HI.getText().toString());
        int b = Integer.parseInt(HF.getText().toString());
        int c = Integer.parseInt(MI.getText().toString());
        int d = Integer.parseInt(MF.getText().toString());


        valorTotalhoras = a+b;
        valorTotalmin = c+d;
        while (valorTotalmin < 0){
            valorTotalhoras--;
            valorTotalmin = valorTotalmin + 60;


        }

        HT.setText(valorTotalhoras);
        MT.setText(valorTotalmin);


    }

    public void subtraiClick(View view){
        int valorTotalhoras;
        int valorTotalmin;

        int a = Integer.parseInt(HI.getText().toString());
        int b = Integer.parseInt(HF.getText().toString());
        int c = Integer.parseInt(MI.getText().toString());
        int d = Integer.parseInt(MF.getText().toString());




        while (c > 59){
            a++;
            c = c - 60;
        }
        while (d > 59){
            b++;
            d = d-60;

        }
        if(b > a){
            valorTotalhoras = b - a;
            valorTotalmin = d - c;

        }
        else{
            valorTotalhoras = a-b;
            if (d > c){
                valorTotalmin = d-c;
            }
            else{
                valorTotalmin = c-d;
            }

        }
        while (valorTotalmin < 0){
            valorTotalhoras--;
            valorTotalmin = valorTotalmin + 60;


        }
        HT.setText(valorTotalhoras + "");
        MT.setText(valorTotalmin + "");

    }
    public void limpar(View l){
        HI.setText("");
        HF.setText("");
        MI.setText("");
        MF.setText("");
        HT.setText("H");
        MT.setText("M");



    }
}